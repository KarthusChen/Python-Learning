class Employee:
    def __init__(self,name="",hoursWorked=0,houlyRate=0):
        self.name=name
        self.housWorked=hoursWorked
        self.houlyRate=houlyRate

    