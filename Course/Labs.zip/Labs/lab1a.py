t=2
y=-16*t**2+53*t+5

print("The height of the ball after ",t ," seconds is ",y," ft.",sep="")