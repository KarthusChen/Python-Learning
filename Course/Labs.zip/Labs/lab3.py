List1=[2,4,6,8,10]

num=int(input("Enter an int:"))
if num in List1:
    print("That number is in the list.")
else:
    print("That number is not in the list.")