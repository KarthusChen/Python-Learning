name = 'grace hopper'
word1 = name[2] + name[3] + name[4]
print(word1)  # Outputs: ace
word2 = name[6] + name[7] + name[8]
print(word2)  # Outputs: hop
word3 = name[9] + name[10] + name[11]
print(word3)  # Outputs: per
