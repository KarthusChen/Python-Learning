def print_it(string):
    Index=0
    for char in string:
        print(Index,": ",char)
        Index+=1

print_it("hello")