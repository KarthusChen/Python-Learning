Inchies=float(input("Enter a measurement in inches: "))
Centimeters= Inchies*2.54

print(Inchies," inchies is equal to ",Centimeters," centimeters.",sep="")
