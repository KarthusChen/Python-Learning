name=input("Enter your name:")

print("Hello, ",name,". Nice to meet you.",sep="")