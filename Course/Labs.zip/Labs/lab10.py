a = {1, 3, 5}
b = {5, 7, 9}

print(a & b) 

print(a | b) 

print(a - b) 

print(a ^ b)